# GAME ROOM TV

Plataforma multijugador: Fire TV como pantalla y teléfonos Android/iPhone como controles.

## Stack
React + Vite + Supabase Auth/Postgres/Realtime + Netlify.

## Supabase
1. Crea un proyecto.
2. En SQL Editor ejecuta `supabase/schema.sql`.
3. Authentication > Providers: Email habilitado.
4. Project Settings > API copia Project URL y Publishable/anon key.
5. En Netlify crea `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY`. Nunca publiques una service_role key.

## Netlify
Build: `npm run build`
Publish: `dist`
SPA fallback ya está en `netlify.toml`.

## Uso
TV: abre la web y pulsa SOY LA TV. Se crea una sala y aparece un código.
Celular: crea/inicia sesión, introduce el código y entra.
La sala admite hasta 4 jugadores.

## Nota
El proyecto está diseñado para usar Realtime para lobby/chat/estado. Los juegos usan el estado de sala para sincronizar puntuaciones y controles.
