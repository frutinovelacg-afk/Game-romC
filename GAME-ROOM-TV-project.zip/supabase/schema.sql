create extension if not exists pgcrypto;

create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique,
 created_at timestamptz not null default now()
);

create table if not exists public.rooms(
 id uuid primary key default gen_random_uuid(),
 code text not null unique,
 admin_id uuid references public.profiles(id) on delete set null,
 status text not null default 'lobby' check(status in ('lobby','playing','results','closed')),
 selected_game text,
 game_state jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.room_players(
 room_id uuid references public.rooms(id) on delete cascade,
 player_id uuid references public.profiles(id) on delete cascade,
 joined_at timestamptz not null default now(),
 score integer not null default 0,
 primary key(room_id,player_id)
);

create table if not exists public.games(
 id text primary key,
 name text not null,
 min_players integer not null default 2,
 max_players integer not null default 4,
 description text not null default ''
);

create table if not exists public.player_stats(
 player_id uuid references public.profiles(id) on delete cascade,
 games_played integer not null default 0,
 wins integer not null default 0,
 losses integer not null default 0,
 total_points integer not null default 0,
 record_points integer not null default 0,
 primary key(player_id)
);

create table if not exists public.game_results(
 id uuid primary key default gen_random_uuid(),
 room_id uuid references public.rooms(id) on delete cascade,
 game_id text references public.games(id),
 player_id uuid references public.profiles(id) on delete cascade,
 score integer not null default 0,
 placement integer,
 created_at timestamptz not null default now()
);

create table if not exists public.chat_messages(
 id uuid primary key default gen_random_uuid(),
 room_id uuid references public.rooms(id) on delete cascade,
 player_id uuid references public.profiles(id) on delete cascade,
 username text not null,
 message text not null check(length(message) between 1 and 300),
 created_at timestamptz not null default now()
);

insert into public.games(id,name,min_players,max_players,description) values
('race','Carrera',2,4,'Corre y llega primero a la meta.'),
('penalties','Penaltis',2,4,'Apunta y dispara para marcar.'),
('match','Fútbol Match',2,4,'Partido rápido con controles táctiles.'),
('target','Tiro al Blanco',2,4,'Pulsa objetivos que aparecen en pantalla.'),
('quiz','Quiz',2,4,'Preguntas rápidas para todos.'),
('avoid','Evita Obstáculos',2,4,'Muévete y sobrevive el mayor tiempo.'),
('snake','Snake',2,4,'Come puntos y crece sin chocarte.'),
('runner','Endless Runner',2,4,'Salta obstáculos y suma distancia.'),
('coins','Atrapa Monedas',2,4,'Mueve tu jugador para atrapar monedas.'),
('breakout','Breakout',2,4,'Mueve la paleta y rompe bloques.'),
('spaceship','Spaceship',2,4,'Esquiva meteoritos y dispara.'),
('pong','Pong',2,4,'Pong multijugador con controles táctiles.')
on conflict(id) do nothing;

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.room_players enable row level security;
alter table public.player_stats enable row level security;
alter table public.game_results enable row level security;
alter table public.chat_messages enable row level security;

create policy "profiles readable" on public.profiles for select to authenticated using(true);
create policy "own profile insert" on public.profiles for insert to authenticated with check(auth.uid()=id);
create policy "own profile update" on public.profiles for update to authenticated using(auth.uid()=id);
create policy "rooms readable" on public.rooms for select to authenticated using(true);
create policy "rooms insert" on public.rooms for insert to authenticated with check(auth.uid()=admin_id);
create policy "rooms update admin" on public.rooms for update to authenticated using(auth.uid()=admin_id);
create policy "players readable" on public.room_players for select to authenticated using(true);
create policy "players join" on public.room_players for insert to authenticated with check(auth.uid()=player_id);
create policy "players own leave" on public.room_players for delete to authenticated using(auth.uid()=player_id or exists(select 1 from public.rooms r where r.id=room_id and r.admin_id=auth.uid()));
create policy "stats readable" on public.player_stats for select to authenticated using(true);
create policy "stats own write" on public.player_stats for all to authenticated using(auth.uid()=player_id) with check(auth.uid()=player_id);
create policy "results readable" on public.game_results for select to authenticated using(true);
create policy "results insert" on public.game_results for insert to authenticated with check(auth.uid()=player_id);
create policy "chat readable" on public.chat_messages for select to authenticated using(true);
create policy "chat insert" on public.chat_messages for insert to authenticated with check(auth.uid()=player_id);

alter publication supabase_realtime add table public.rooms;
alter publication supabase_realtime add table public.room_players;
alter publication supabase_realtime add table public.chat_messages;
